//===> panggil library untuk akses ke LCD.
//=====> library lcd .
#include <Wire.h> 
#include <LiquidCrystal_I2C.h>
//============> LCD <================//
LiquidCrystal_I2C lcd(0x27, 16, 2);
//====================================//

//===> Parameter pin ini di gunakan untuk setting pin I2C pada module ESP . dikarenakan-
//===> module ESP juga memiliki lebih dari 1 pin komunikasi I2C . jadi kita harus -
//===> mendeskripsi ke dalam parameter untuk pin SCL dan SDA diletaka dimana .

//===> untuk wemos D1 Mini dan Nodemcu pin i2c pada [ SCL = D1 dan SDA = D2 ]
//===> untuk wemos D1 R1 pin i2c pada [ SCL = D15 dan SDA = D14]
//===> Sesuaikan pin dengan datasheet Pinout Mikrokontroller . Karena bisa saja pada ESPlain-
//===> memiliki posisi i2c pin yang berbeda .

const int sclPin = D1; //==> Pin SDA .
const int sdaPin = D2; //==> Pin SCL .

//===>Fungsi untuk inisialisai awal LCD I2C .
void inisial_LCD(){
  //====> Inisial komponen LCD .
  Wire.begin(sdaPin, sclPin);
  lcd.begin();
  lcd.println("Ready...");
}


//===> Kode program untuk Timer LCD . Kode program ini untuk memberikan jadwal update tampilan-
//===> dilcd . Jadi LCD akan di update untuk beberapa puluh atau ratus mili second sekali .
//===> cotoh set update 500 . jadi 500 mili second sekali lcd akan diupdate tampilan data nya.
//===> Hal ini di perlukan untuk membagi sumber daya perangkat mikrokontroller dengan prorgam lain.
//===> contoh : program pembaca kartu rfid , pengiriman data ke server dll .

//===> parameter variabel yang menyiman data pewaktuan . Jadi variabel akan menyimpan data nilai dari -
//===> fungsi millis() [ Fungsi ini adalah timer bawaan arduino ] . Untuk mendapatkan waktu berjalan-
//===> maka kita akan mengurangi millis() dengan variabel penyimpan data pewaktuan .
unsigned long tmUpdateLcd = millis();

//===> parameter tmMaxUpdateLCD . parameter ini di gunakan untuk menyimpan informasi . Periode waktu update-
//===> Jadi berapa detik sekali LCD akan di update . 
//===> Pada parameter ini bisa di setting untuk kecepatan update dari LCD .
//===> satuan adalah milis detik . Jadi jika kita set 200 maka lcd akan di update 200 mili detik sekali.
int tmMaxUpdateLCD = 700 ;

//===> Fungsi untuk mengambil informasi timer yang sudah berjalan .  jadi fungsi ini di gunakan untuk-
//===> menghitung waktu , anggap saja seperti stop watch .
//===> Step algoritma :
//===> Simpan terlebih dahulu millis() pada "tmUpdateLcd" . [ tmUpdateLcd = millis() ]
//===> lalu tunggu beberapa detik , contoh 5 detik .
//===> lalu kurangi millis() sekarang dengan variabel "tmUpdateLcd"  . [ waktu = millis() - tmUpdateLcd ].
//===> maka kita akan mendapat data 5000 mili second atau 5 detik . pada variabel waktu berisi data 5 detik.
//===> OUTPUT FUNGSI :
//===> output dari fungsi ini berupa interger dengan satuan perhitungan adalah detik .
int hitungTimerUpdate_LCD(){
  //===> hitung dan kembalikan data perhitungan waktu ke system utama .
  //===> Step proses :
  //===> [ 1 ].  Kurangi millis() dengan variabel tmUpdateLcd.
  //===> [ 2 ].  hasil didapat berupa mili second .
  return (millis()-tmUpdateLcd) ; 
}


//===> Fungsi untuk memberkan informasi berupa data boolean ,apakah lcd sudah waktu nya di update .
//===> sistem kerja fungsi ini cukup mudah .
//===> memanggil fungsi "hitungTimerUpdate_LCD" dan membandingkan dengan variabel "tmMaxUpdateLCD".
//===> Jika hasil perhitungan sudah melebihi waktu update lcd ,maka output adalah true .
bool sudahSaatNyaUpdateLCD(){
  //===> panggil fungsi "hitungTimerUpdate_LCD" dan bandingkan dengan variabel "tmMaxUpdateLCD".
  return hitungTimerUpdate_LCD() > tmMaxUpdateLCD ;
}

//===> Fungsi ini di gunakan untuk mereset timer update lcd kembali ke 0 .
//===> Jika timer sudah mencapai batas nya dan update lcd telah selesai , maka yang harus di lakukan-
//===> adalah dengan mereset timer , agar di ulang dari awal.
//===> mudah nya ini adalah stopwatch , jika sudah waktu nya berbunyi dan selesai .maka kita tinggal -
//===> mereset untuk mulai dari awal .
void resetTimerLcd(){
  //==> untuk mereset timer , kita tinggal mengisi variabel "tmUpdateLcd" dengan nilai millis yang sekarang-
  //==> karena nilai millis() akan terus menghitung dari 0 sampai dengan batasan .[ selama 3 hari ].
  tmUpdateLcd = millis();
}


//===> Fungsi Update LCD untuk menampilkan informasi awal saat alat peratama kali dinyalakan .
//===> fungsi ini untuk tampilan awal saat arduino dalam mode stand by.
void tampilan_mode_standby(){
  //===> Cek jika sudah waktu nya update display.
  if( sudahSaatNyaUpdateLCD() == true ){
    //===> [ 1 ]. Reset Tampilan LCD menjadi Blank / Kosong .
    lcd.clear();

    //===> [ 2 ]. Tampilkan data tegangan sensor dari output analog.
    lcd.setCursor( 0 , 0 );
    lcd.print("Aout : " + String(bacaSensor_Flame_analog() , 1) + " V");
    lcd.setCursor( 0 , 1 );
	//===> [ 2 ]. Tampilkan data digital sensor dari output digital.
	if( bacaSensor_Flame_digital() == terdeteksiApi ){
		lcd.print("Terdeteksi Api");
	}else{
		lcd.print("Tidak Ada Api");
	}
  
    //===> panggil fungsi "resetTimerLcd()" untuk kembali mereset timer ke awal .
    resetTimerLcd();
  }

}
