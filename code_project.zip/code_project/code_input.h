//====> Baca port analog A0 lokasi pin Sensor.
float bacaSensor_Flame_analog(){
	int temp = map( analogRead(A0) , 0 , 1024 , 0 , 5000 );
	return float(temp) / 1000.0 ;
}

//===> Baca port sensor flame.
bool bacaSensor_Flame_digital(){
	return digitalRead( pin_Dout_flame );
}
