//=====> Parameter pin Input / Output external komponen.
int pin_buzzer 		= D4 ;
int pin_Aout_flame 	= A0 ;
int pin_Dout_flame 	= D3 ;


//=====> Parameter boolean Ya dan Tidak.
bool ya = true ;
bool tidak = false ;

//=====> Parameter status sensor.
bool terdeteksiApi = false ;
bool Tidak_terdeteksiApi = true ;

//=====> Parameter timer upload data.
unsigned long tm_Update_dataSerial = millis();
float waktuUpdate_dataSerial = 1000 ; //==> Satuan update millis.

//====> Parameter jika ada perubahan data sensor.
bool data_sensor_berubah = false ;

//====> Parameter data terakhir tegangan analog dan digital-
//====> sensor.
float last_Vout_sensor = 0.0 ;
float ambang_Batas_Vout = 0.2 ; //==> Satuan Volt.
bool last_Dout_sensor = false ;
