//==================================>
void buzzer( unsigned long time_  , float persen_tone ){
  pinMode( pin_buzzer , OUTPUT );
  //=============================>
  unsigned long times = millis();
  while( (millis()-times) < time_ ){
    //=============================>
    digitalWrite( pin_buzzer , HIGH );
    delay( 200 * (persen_tone/100.0)  );
    digitalWrite( pin_buzzer , LOW );
    delay( 400 * ((100.0-persen_tone)/100.0)  );
  }
  digitalWrite( pin_buzzer , LOW ); 
}
